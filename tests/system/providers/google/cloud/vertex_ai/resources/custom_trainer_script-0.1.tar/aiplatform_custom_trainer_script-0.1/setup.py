from setuptools import find_packages
from setuptools import setup

setup(
    name='aiplatform_custom_trainer_script',
    version='0.1',
    packages=find_packages(),
    install_requires=("gcsfs==0.7.1"),
    include_package_data=True,
    description='My training application.'
)